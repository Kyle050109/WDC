// db.js
const mysql = require('mysql2/promise');
require('dotenv').config();

const db = mysql.createPool({
  socketPath: '/tmp/mysql.sock',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'eastern_front'
});

db.getConnection()
  .then(() => console.log('✅ Connected to MySQL via socket'))
  .catch(err => console.error('❌ Socket connection error:', err));

module.exports = db;
