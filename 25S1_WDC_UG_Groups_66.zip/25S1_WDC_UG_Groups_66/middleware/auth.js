function requireLogin(req, res, next) {
  if (!req.session.user) {
    return res.redirect('/login');
  }

  res.setHeader('Cache-Control', 'no-store'); //avoid browser cache
  next();
}

module.exports = requireLogin;
