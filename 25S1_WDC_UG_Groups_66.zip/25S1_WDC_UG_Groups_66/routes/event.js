// routes/events.js
const express = require('express');
const router = express.Router();
const db = require('../db');

// GET /api/events
router.get('/api/events', async (req, res) => {
  try {
    const [rows] = await db.execute('SELECT * FROM events');
    res.json(rows);
  } catch (err) {
    console.error('Failed to fetch events:', err);
    res.status(500).json({ error: 'Failed to load events' });
  }
});

module.exports = router;
