// routes/register.js
const express = require('express');
const bcrypt = require('bcrypt');
const db = require('../db');

const router = express.Router();

// GET registration page
router.get('/', (req, res) => {
   res.render('register', { error: null, user: req.session.user || null });
});

// POST registration logic
router.post('/', async (req, res) => {
  const { username, email, password, avatar, theme_preference } = req.body;

  try {
    const [existing] = await db.execute(
      'SELECT * FROM users WHERE username = ? OR email = ?',
      [username, email]
    );

    if (existing.length > 0) {
      return res.render('register', {
        error: 'User name or email already exists',
        user: req.session.user || null
      });
    }

    const hash = await bcrypt.hash(password, 10);
    await db.execute(
      'INSERT INTO users (username, email, password_hash, avatar, theme_preference) VALUES (?, ?, ?, ?, ?)',
      [username, email, hash, avatar, theme_preference]
    );

    res.redirect('/login');
  } catch (err) {
    console.error('Registration error:', err);
    res.render('register', { error: 'Registration failed due to server error.' });
  }
});

module.exports = router;
