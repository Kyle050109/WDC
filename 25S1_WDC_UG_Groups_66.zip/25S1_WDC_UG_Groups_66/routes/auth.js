// routes/auth.js
const express = require('express');
const router = express.Router();
const logoutRoute = require('./logout');
const mapRoute = require('./map');
const registerRoute = require('./register');
const loginRoute = require('./login');
const themeRoute = require('./theme');
const eventApi = require('./events');

router.use('/register', registerRoute);
router.use('/login', loginRoute);
router.use('/', themeRoute);
router.use('/logout', logoutRoute);
router.use('/', mapRoute);
router.use('/', eventApi);
module.exports = router;
