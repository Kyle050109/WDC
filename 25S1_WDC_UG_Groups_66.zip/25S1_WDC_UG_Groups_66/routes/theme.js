// routes/theme.js
const express = require('express');
const db = require('../db');

const router = express.Router();

// POST /update-theme
router.post('/update-theme', async (req, res) => {
  const userId = req.session.user?.id;
  const theme = req.body.theme;

  if (!userId) return res.sendStatus(401);

  try {
    await db.execute(
      'UPDATE users SET theme_preference = ? WHERE user_id = ?',
      [theme, userId]
    );
    req.session.user.theme_preference = theme; // sync session
    res.sendStatus(200);
  } catch (err) {
    console.error('Theme update failed:', err);
    res.sendStatus(500);
  }
});

module.exports = router;
