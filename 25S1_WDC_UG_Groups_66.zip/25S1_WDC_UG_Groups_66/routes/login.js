// routes/login.js
const express = require('express');
const bcrypt = require('bcrypt');
const db = require('../db');

const router = express.Router();

// GET login page
router.get('/', (req, res) => {
    res.render('login', {
        error: null,
        user: req.session.user || null
      });
      
});

// POST enrty
router.post('/', async (req, res) => {
  const { identifier, password } = req.body;

  try {
    const [rows] = await db.execute(
      'SELECT * FROM users WHERE username = ? OR email = ?',
      [identifier, identifier]
    );
//user not found
    if (rows.length === 0) {
      return res.render('login', {
        error: 'User not found',
        user: null
      });
      
    }

    const user = rows[0];
    const isMatch = await bcrypt.compare(password, user.password_hash);
// password wrong
    if (!isMatch) {
      return res.render('login', {
        error: 'Incorrect password',
        user: null
      });
      
    }

    // login then set session
    req.session.user = {
      id: user.user_id,
      username: user.username,
      is_admin: user.is_admin,
      theme_preference: user.theme_preference
    };

    res.redirect('/');
  } catch (err) {
    console.error('Login failed:', err);
    res.render('login', { error: 'Login failed due to server error.' });
  }
});



module.exports = router;
