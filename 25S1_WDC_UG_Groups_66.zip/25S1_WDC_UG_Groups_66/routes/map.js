// routes/map.js
const express = require('express');
const router = express.Router();

// login protection middleware
const requireLogin = require('../middleware/auth');

router.get('/map', requireLogin, (req, res) => {
  res.setHeader('Cache-Control', 'no-store');
  res.render('map', { user: req.session.user });
});


module.exports = router;
