// routes/logout.js
const express = require('express');
const router = express.Router();

// GET /logout
router.get('/', (req, res) => {
  req.session.destroy(err => {
    if (err) {
      console.error('Logout failed:', err);
      return res.redirect('/');
    }

    res.clearCookie('connect.sid'); // optional: clean cookie
    res.render('logout', { user: null });
  });
});

module.exports = router;
